import ui.GameJFrame;
import ui.LoginJFrame;
import ui.RegisterJFrame;

public class App {
    public static void main(String[] args) {
        //表示程序的启动入口

        //如果我们想要开启一个界面，就创建谁的对象就可以了
        //1.注册
        //new RegisterJFrame();
        //2.登录
        new LoginJFrame();
        //3.游戏
        //new GameJFrame();
    }
}
