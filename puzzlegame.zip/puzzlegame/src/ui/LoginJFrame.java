package ui;

import domain.User;
import util.CodeUtil;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class LoginJFrame extends JFrame implements MouseListener {
    //LoginJFrame  表示登录界面
    //以后所有跟登录相关的代码，都写在这里

    JButton login = new JButton();
    JButton register = new JButton();

    JTextField code = new JTextField();
    JTextField username = new JTextField();
    JPasswordField password = new JPasswordField();

    //正确的验证码
    JLabel rightCode = new JLabel();


    //创建一个集合存储正确的用户名和密码
    static ArrayList<User> list = new ArrayList<>();

    static {
        list.add(new User("sober", "123321"));
        list.add(new User("xll123", "159753"));
    }


    public LoginJFrame() {
        //在创建登录界面的时候，同时给这个界面去设置一些信息
        //初始化界面
        initJFrame();//Alt + shift + M 选中代码块快捷生成方法

        //在界面中添加内容
        initView();


        //设置界面显示，建议放在最后
        this.setVisible(true);
    }

    private void initView() {
        //返回输入框中用户输入的数据
        //细节：如果用户没有输入，返回的是一个长度为0的字符串
        //getText();
        //修改数据
        //setText(要修改的内容);
        //1. 添加用户名文字
        JLabel usernameText = new JLabel(new ImageIcon("puzzlegame\\image\\login\\用户名.png"));
        usernameText.setBounds(106, 135, 47, 17);
        this.getContentPane().add(usernameText);
        //2.添加用户名输入框

        username.setBounds(185, 134, 200, 30);
        this.getContentPane().add(username);
        //3.添加密码文字
        JLabel passwordText = new JLabel(new ImageIcon("puzzlegame\\image\\login\\密码.png"));
        passwordText.setBounds(120, 195, 32, 16);
        this.getContentPane().add(passwordText);
        //4.密码输入框

        password.setBounds(185, 195, 200, 30);
        this.getContentPane().add(password);
        //验证码提示
        JLabel codeText = new JLabel(new ImageIcon("puzzlegame\\image\\login\\验证码.png"));
        codeText.setBounds(123, 256, 50, 30);
        this.getContentPane().add(codeText);
        //验证码的输入框

        code.setBounds(185, 256, 100, 30);
        this.getContentPane().add(code);

        String codeStr = CodeUtil.getCode();

        //设置内容
        rightCode.setText(codeStr);
        //位置和宽高
        rightCode.setBounds(290, 256, 50, 30);
        //添加到界面
        this.getContentPane().add(rightCode);

        //5.添加登录按钮

        login.setBounds(113, 310, 128, 47);
        login.setIcon(new ImageIcon("puzzlegame\\image\\login\\登录按钮.png"));
        //去除按钮的默认边框
        login.setBorderPainted(false);
        //去除按钮的默认背景
        login.setContentAreaFilled(false);
        this.getContentPane().add(login);

        //6.添加注册按钮

        register.setBounds(246, 310, 128, 47);
        register.setIcon(new ImageIcon("puzzlegame\\image\\login\\注册按钮.png"));
        //去除按钮的默认边框
        register.setBorderPainted(false);
        //去除按钮的默认背景
        register.setContentAreaFilled(false);
        this.getContentPane().add(register);

        //7.添加背景图片
        JLabel background = new JLabel(new ImageIcon("puzzlegame\\image\\login\\background.png"));
        background.setBounds(0, 0, 470, 390);
        this.getContentPane().add(background);

        //给按钮添加事件
        login.addMouseListener(this);
        register.addMouseListener(this);
        rightCode.addMouseListener(this);
    }

    private void initJFrame() {
        //设置界面的宽高
        this.setSize(488, 430);
        //设置界面的标题
        this.setTitle("拼图游戏 V1.0登录");
        //设置界面置顶
        this.setAlwaysOnTop(true);
        //设置界面居中
        this.setLocationRelativeTo(null);
        //设置关闭模式
        this.setDefaultCloseOperation(3);
        //取消内部默认布局
        this.setLayout(null);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        //点击按钮
        Object obj = e.getSource();
        //点击了登录按钮时
        if (obj == login) {
            //获取用户输入的验证码
            String codeInput = code.getText();
            //获取两个文本输入框中的内容
            String usernameInput = username.getText();
            String passwordInput = password.getText();
            //获取集合中的对象
            User u1 = list.get(0);
            //获取用户输入的用户名，密码
            //创建一个User对象
            User userInfo = new User(usernameInput, passwordInput);
            System.out.println("用户输入的用户名为" + usernameInput);
            System.out.println("用户输入的密码为" + passwordInput);
            //先比较验证码是否正确
            if (codeInput.length() == 0) {
                System.out.println("验证码为空");
                showJDialog("验证码为空");
            } else if (!(codeInput.equalsIgnoreCase(rightCode.getText()))) {
                System.out.println("验证码输入有误！");
                showJDialog("验证码输入有误！");
            } else if (usernameInput.length() == 0 || passwordInput.length() == 0) {
                //判断用户名和密码是否为空，只要有一个为空就不行
                //细节：如果为空，在代码中获取的不是null，而是长度为0的字符串 - ""
                System.out.println("用户名和密码不能为空");
                showJDialog("用户名和密码不能为空");
            }else if (contains(userInfo)){
                //用户名，密码比较正确，显示登录成功 - 跳转到游戏界面
                System.out.println("用户名和密码正确，登录成功！");
                this.setVisible(false);
                new GameJFrame();
            }else{
                //用户名，密码比较错误，提示错误 - 弹窗
                System.out.println("用户名或密码错误");
                showJDialog("用户名或密码错误");
            }
        }else if (obj == register){
            System.out.println("点击了注册按钮");
        }else if (obj == rightCode){
            //获取一个新的验证码
            String newCode = CodeUtil.getCode();
            rightCode.setText(newCode);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        //System.out.println("按下未松");
        if (e.getSource() == login){
            //切换登录按钮的背景图片
            login.setIcon(new ImageIcon("puzzlegame\\image\\login\\登录按下.png"));
        }else if (e.getSource() == register){
            register.setIcon(new ImageIcon("puzzlegame\\image\\login\\注册按下.png"));
        }

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        //按钮松开
        if (e.getSource() == login){
            login.setIcon(new ImageIcon("puzzlegame\\image\\login\\登录按钮.png"));
        }else if (e.getSource() == register){
            register.setIcon(new ImageIcon("puzzlegame\\image\\login\\注册按钮.png"));
        }


    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    //用弹窗展示输入错误
    public void showJDialog(String content) {
        //创建一个弹框对象
        JDialog jDialog = new JDialog();
        //给弹框设置大小
        jDialog.setSize(200, 150);
        //让弹框置顶
        jDialog.setAlwaysOnTop(true);
        //让弹框居中
        jDialog.setLocationRelativeTo(null);
        //弹框不关闭永远无法操作下面的界面
        jDialog.setModal(true);
        //设置弹框标题
        jDialog.setTitle("错误提示！");

        //创建JLabel对象管理文字并添加到弹框当中
        JLabel warning = new JLabel(content);
        warning.setBounds(0, 0, 200, 150);
        jDialog.getContentPane().add(warning);

        //让弹框展示出来
        jDialog.setVisible(true);
    }
    
    //判断用户在集合中是否存在
    public boolean contains(User userInfo){
        //遍历集合寻找对应的用户
        for (int i = 0; i < list.size(); i++) {
            User rightUser = list.get(i);
            if (rightUser.getUsername().equals(userInfo.getUsername()) &&
            rightUser.getPassword().equals(userInfo.getPassword())){
                //表示有相同的直接返回true
                return true;
            }
        }
        //循环结束找不到用户
        return false;
    }
}
