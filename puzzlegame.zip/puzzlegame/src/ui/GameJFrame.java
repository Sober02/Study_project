package ui;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

public class GameJFrame extends JFrame implements KeyListener, ActionListener {
    //JFrame 界面 窗体
    //GameJFrame  表示游戏界面
    //以后所有跟游戏相关的代码，都写在这里

    //定义一个二维数组
    //日的: 用来管理数据
    //加载图片的时候，会根据二维数组中的数据进行加载
    int[][] data = new int[4][4];
    //用来记录空白格的位置
    int x = 0;
    int y = 0;

    //定义一个正确的二维数组win
    int[][] win = new int[][]{
            {1, 2, 3, 4},
            {5, 6, 7, 8},
            {9, 10, 11, 12},
            {13, 14, 15, 0}
    };


    //定义一个变量来记录当前展示图片的路径
    //String path = "puzzlegame\\image\\animal\\animal3\\";
    String path = "puzzlegame\\image\\girl\\girl1\\";

    //定义一个统计步数的变量
    int step = 0;

    //创建选项下面的条目对象
    JMenuItem rePlayItem = new JMenuItem("重新游戏");
    JMenuItem reLoginItem = new JMenuItem("重新登录");
    JMenuItem closeItem = new JMenuItem("关闭游戏");

    JMenuItem accountItem = new JMenuItem("公众号");

    JMenuItem girlItem = new JMenuItem("美女");
    JMenuItem animalItem = new JMenuItem("动物");
    JMenuItem sportItem = new JMenuItem("运动");

    public GameJFrame() {

        //初始化界面
        initJFrame();

        //初始化菜单
        initJMenuBar();

        //初始化数据
        initData();

        //初始化图片
        initImage();


        //设置界面显示，建议放在最后
        this.setVisible(true);
    }

    //初始化数据(打乱)
    private void initData() {
        //1.定义一个一维数组
        int[] tempArr = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};

        //2.打乱数组中的数据顺序
        Random r = new Random();
        for (int i = 0; i < tempArr.length; i++) {
            int index = r.nextInt(tempArr.length);
            int temp = tempArr[i];
            tempArr[i] = tempArr[index];
            tempArr[index] = temp;
        }

        System.out.println();

        //方法一：
        //4.遍历一维数组将数据添加到二维数组中

        for (int i = 0; i < tempArr.length; i++) {
            //在一维数组中找到0
            if (tempArr[i] == 0) {
                x = i / 4;  //在二维数组中i的索引
                y = i % 4;  //在二维数组中j的索引
            }
            data[i / 4][i % 4] = tempArr[i];
        }
    }

    //初始化图片
    //添加图片的时候，就需要按照二维数组中管理的数据添加图片
    private void initImage() {
        //创建一个图片ImageIcon的对象
        // icon = new ImageIcon("E:\\code\\Project2\\puzzlegame\\image\\animal\\animal3\\1.jpg");
        //创建一个JLabel的对象（管理容器）

        //细节：先加载的图片会在上面，后面加载的图片在下面。
        //所以背景图片加载最后、

        //清空原本已经出现的所有图片
        this.getContentPane().removeAll();


        if (victory()) {
            //显示胜利的图标
            JLabel winJLabel = new JLabel(new ImageIcon("E:\\code\\Project2\\puzzlegame\\image\\win.png"));
            winJLabel.setBounds(203, 298, 197, 73);
            this.getContentPane().add(winJLabel);
        }

        //添加一个计步器
        JLabel count = new JLabel("步数：" + step);
        count.setBounds(30, 20, 120, 50);
        this.getContentPane().add(count);

        //外循环 --- 把内循环重复执行了4次。
        for (int i = 0; i < 4; i++) {
            //内循环 --- 表示在一行添加4张图片
            for (int j = 0; j < 4; j++) {
                //获取当前要加载图片的序号
                int num = data[i][j];
                //创建一个JLabel对象（管理容器）
                //绝对路径：一定是从盘符开始的
                //JLabel jLabel = new JLabel(new ImageIcon("E:\\code\\Project2\\puzzlegame\\image\\animal\\animal3\\" + num + ".jpg"));
                //相对路径：不是从盘符开始的
                //相对路径是相对当前项目而言的。   aaa\\bbb
                // 在当前项目下，去找aaa文件夹，里面再找bbb文件夹。
                JLabel jLabel = new JLabel(new ImageIcon(path + num + ".jpg"));
                //指定图片位置
                jLabel.setBounds(105 * j + 83, 105 * i + 134, 105, 105);

                //添加图片的边框
                //0：让图片凸起来
                //1：让图片凹下去
                //jLabel.setBorder(new BevelBorder(1));
                jLabel.setBorder(new BevelBorder(BevelBorder.LOWERED));

                //把管理容器添加到界面中
                //this.add(jLabel);
                this.getContentPane().add(jLabel);
            }
        }
        //添加背景图片
        JLabel jLabelBg = new JLabel(new ImageIcon("puzzlegame\\image\\background.png"));
        //指定图片位置
        jLabelBg.setBounds(40, 40, 508, 560);
        //把管理容器添加到界面中
        this.getContentPane().add(jLabelBg);

        //刷新一下界面
        this.getContentPane().repaint();
    }

    private void initJMenuBar() {
        //创建整个菜单对象
        JMenuBar jMenuBar = new JMenuBar();

        //创建菜单上面的两个选项的对象 (功能 关于我们)
        JMenu functionJMenu = new JMenu("功能");
        JMenu aboutJMenu = new JMenu("关于我们");
        JMenu replaceImageJMenu = new JMenu("更换图片");


        //在菜单中嵌套二级菜单 — JMenu里面可以再次添加其他的JMenu
        functionJMenu.add(replaceImageJMenu);
        replaceImageJMenu.add(girlItem);
        replaceImageJMenu.add(animalItem);
        replaceImageJMenu.add(sportItem);
        //将每一个选项下面的条目添加到选项当中
        functionJMenu.add(rePlayItem);
        functionJMenu.add(reLoginItem);
        functionJMenu.add(closeItem);

        aboutJMenu.add(accountItem);

        //将菜单里面的两个选项添加到菜单当中
        jMenuBar.add(functionJMenu);
        jMenuBar.add(aboutJMenu);

        //最后给整个界面设置菜单
        this.setJMenuBar(jMenuBar);

        //给条目对象添加点击事件
        rePlayItem.addActionListener(this);
        reLoginItem.addActionListener(this);
        closeItem.addActionListener(this);
        accountItem.addActionListener(this);
        girlItem.addActionListener(this);
        animalItem.addActionListener(this);
        sportItem.addActionListener(this);

    }

    private void initJFrame() {
        //取消内部默认居中方式
        this.setLayout(null);
        //设置界面的宽高
        this.setSize(603, 680);
        //设置界面的标题
        this.setTitle("拼图单机版 v1.0");
        //设置界面置顶
        this.setAlwaysOnTop(true);
        //设置界面居中
        this.setLocationRelativeTo(null);
        //设置关闭模式
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        //给整个界面添加键盘监听事件
        this.addKeyListener(this);
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    //按下不松时调用这个方法
    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == 65) {
            //清空原本已经出现的所有图片
            this.getContentPane().removeAll();

            JLabel jLabel = new JLabel(new ImageIcon(path + "all.jpg"));
            jLabel.setBounds(83, 134, 420, 420);
            this.getContentPane().add(jLabel);

            //添加背景图片
            JLabel jLabelBg = new JLabel(new ImageIcon("puzzlegame\\image\\background.png"));
            //指定图片位置
            jLabelBg.setBounds(40, 40, 508, 560);
            //把管理容器添加到界面中
            this.getContentPane().add(jLabelBg);

            //刷新一下界面
            this.getContentPane().repaint();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        //判断游戏是否胜利，如果胜利，此方法需要直接结束，不能再执行下面的移动代码了
        if (victory()) {
            //结束方法
            return;
        }

        //上 下 左 右 --- 38  40 37 39
        int code = e.getKeyCode();
        //System.out.println(code); //测试上下左右的对面的编号
        if (code == 37) {
            System.out.println("向左移动");
            if (y == 3) {
                //表示空白方块已经在最右方了，他的右边没有图片再能移动了
                return;
            }

            //逻辑:
            //把空白方块右方的数字往左移动
            //x，y 表示空白方块
            //x，y + 1 表示空白方块右方的数字
            data[x][y] = data[x][y + 1];
            //把空白方块下方的数字赋值给空白方块
            data[x][y + 1] = 0;
            //空白格的位置调换了 x++
            y++;
            //每移动一次，计数器就自增一次
            step++;
            //调用方法按照最新的数字加载图片
            initImage();

        } else if (code == 38) {
            System.out.println("向上移动");
            if (x == 3) {
                //表示空白方块已经在最下方了，他的下面没有图片再能移动了
                return;
            }

            //逻辑:
            //把空白方块下方的数字往上移动
            //x，y 表示空白方块
            //x + 1， y 表示空白方块下方的数字
            data[x][y] = data[x + 1][y];
            //把空白方块下方的数字赋值给空白方块
            data[x + 1][y] = 0;
            //空白格的位置调换了 x++
            x++;
            //每移动一次，计数器就自增一次
            step++;
            //调用方法按照最新的数字加载图片
            initImage();

        } else if (code == 39) {
            System.out.println("向右移动");
            if (y == 0) {
                //表示空白方块已经在最左方了，他的左边没有图片再能移动了
                return;
            }

            //逻辑:
            //把空白方块左边方的数字往右移动
            //x，y 表示空白方块
            //x，y - 1 表示空白方块右方的数字
            data[x][y] = data[x][y - 1];
            //把空白方块下方的数字赋值给空白方块
            data[x][y - 1] = 0;
            //空白格的位置调换了 x++
            y--;
            //每移动一次，计数器就自增一次
            step++;
            //调用方法按照最新的数字加载图片
            initImage();

        } else if (code == 40) {
            System.out.println("向下移动");
            if (x == 0) {
                //表示空白方块已经在最上方了，他的上面没有图片再能移动了
                return;
            }

            //逻辑:
            //把空白方块下方的数字往下移动
            //x，y 表示空白方块
            //x + 1， y 表示空白方块下方的数字
            data[x][y] = data[x - 1][y];
            //把空白方块下方的数字赋值给空白方块
            data[x - 1][y] = 0;
            //空白格的位置调换了 x++
            x--;
            //每移动一次，计数器就自增一次
            step++;
            //调用方法按照最新的数字加载图片
            initImage();
        } else if (code == 65) {
            //重新加载原来的图片
            initImage();
        } else if (code == 87) {
            //当按下W键游戏直接获胜
            //创建一个最终效果的二维数组
            data = new int[][]{
                    {1, 2, 3, 4},
                    {5, 6, 7, 8},
                    {9, 10, 11, 12},
                    {13, 14, 15, 0}
            };
            initImage();
        }
    }

    //定义一个方法判断游戏是否胜利
    public boolean victory() {
        //遍历二维数组进行判断
        for (int i = 0; i < data.length; i++) {
            //i : 依次表示二维数组 data里面的索引
            //data[i]: 依次表示每一个一维数组
            for (int j = 0; j < data[i].length; j++) {
                if (data[i][j] != win[i][j]) {
                    //只要有一个数据不一样直接返回false
                    return false;
                }
            }
        }
        //循环结束说明数组遍历完毕，全都一样，返回true
        return true;
    }

    //点击事件
    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        if (obj == rePlayItem) {
            System.out.println("重新游戏");
            //计步器清零
            step = 0;
            //重新打乱二维数组中的数字
            initData();
            //加载图片
            initImage();
        } else if (obj == reLoginItem) {
            System.out.println("重新登录");
            //关闭当前游戏界面
            this.setVisible(false);
            //打开登录窗口
            new LoginJFrame();
        } else if (obj == closeItem) {
            System.out.println("关闭游戏");
            System.exit(0);
        } else if (obj == accountItem) {
            System.out.println("查询公众号");

            //创建一个弹框对象
            JDialog jDialog = new JDialog();
            //创建一个管理图片容器的JLabel对象
            JLabel jLabel = new JLabel(new ImageIcon("puzzlegame\\image\\about.png"));
            //设置位置和宽高 - 他的x，y是作用在弹框对象内的
            jLabel.setBounds(0, 0, 258, 258);
            //把图片添加到弹框中
            jDialog.getContentPane().add(jLabel);
            //给弹框设置大小
            jDialog.setSize(344, 344);
            //让弹框置顶
            jDialog.setAlwaysOnTop(true);
            //让弹框居中
            jDialog.setLocationRelativeTo(null);
            //弹框不关闭则无法操作下面的界面
            jDialog.setModal(true);
            //让弹框显示出来
            jDialog.setVisible(true);
        } else if (obj == girlItem) {
            System.out.println("更换美女图片");
            //更换图片重新计数
            step = 0;
            if (victory()) {
                //如果胜利了更换了图片要清空原本出现的图片
                //重新打乱二维数组中的数字
                initData();
                //加载图片
                initImage();
            }
            //1.随机选取一组美女图片
            int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
            Random r = new Random();
            int index = r.nextInt(arr.length);
            path = "puzzlegame\\image\\girl\\girl" + arr[index] + "\\";
            //2.重新初始化图片
            initImage();
        } else if (obj == animalItem) {
            System.out.println("更换动物图片");
            //更换图片重新计数
            step = 0;
            if (victory()) {
                //如果胜利了更换了图片要清空原本出现的图片
                //重新打乱二维数组中的数字
                initData();
                //加载图片
                initImage();
            }
            //1.随机选取一组美女图片
            int[] arr = {1, 2, 3, 4, 5, 6, 7, 8};
            Random r = new Random();
            int index = r.nextInt(arr.length);
            path = "puzzlegame\\image\\animal\\animal" + arr[index] + "\\";
            //2.重新初始化图片
            initImage();
        }else if (obj == sportItem){
            System.out.println("更换运动图片");
            //更换图片重新计数
            step = 0;
            if (victory()) {
                //如果胜利了更换了图片要清空原本出现的图片
                //重新打乱二维数组中的数字
                initData();
                //加载图片
                initImage();
            }
            //1.随机选取一组美女图片
            int[] arr = {1, 2, 3, 4, 5, 6, 7, 8,9,10};
            Random r = new Random();
            int index = r.nextInt(arr.length);
            path = "puzzlegame\\image\\sport\\sport" + arr[index] + "\\";
            //2.重新初始化图片
            initImage();
        }
    }
}
