package ui;

import javax.swing.*;

public class RegisterJFrame extends JFrame {
    //以后所有跟注册相关的代码，都写在这里

    public  RegisterJFrame(){
        //设置界面的宽高
        this.setSize(488,500);
        //设置界面的标题
        this.setTitle("拼图 - 注册");
        //设置界面置顶
        this.setAlwaysOnTop(true);
        //设置界面居中
        this.setLocationRelativeTo(null);
        //设置关闭模式
        this.setDefaultCloseOperation(3);


        //设置界面显示，建议放在最后
        this.setVisible(true);
    }



}
