package domain;

public class User {
    //属性
    private String username;
    private String password;
    //空参

    public User() {
    }

    //全参

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    //get/set

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
