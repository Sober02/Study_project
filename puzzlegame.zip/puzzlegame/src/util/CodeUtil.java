package util;

import java.util.ArrayList;
import java.util.Random;

public class CodeUtil {
    public static void main(String[] args) {
        System.out.println(getCode());
    }

    public static String getCode() {
        //获取4位随机字母
        //1.创建一个集合存储大小写字母
        ArrayList<Character> list = new ArrayList<>();
        //2.循环添加字母
        for (int i = 0; i < 26; i++) {
            list.add((char) ('a' + i));//a-z
            list.add((char) ('A' + i));//A-Z
        }
        //打印集合
        //System.out.println(list);
        //3.随机获取4个字母生成一个字符串
        Random r = new Random();
        String result = "";
        for (int i = 0; i < 4; i++) {
            int randomIndex = r.nextInt(list.size());
            char c = list.get(randomIndex);
            result = result + c;
        }
        //System.out.println(result);
        //4.获取一位随机数字添加在后面
        int number = r.nextInt(10);
         result = result + number;
        //System.out.println(result);
        //5.将字符串转成字符数组
        char[] chars = result.toCharArray();
        //6.拿着4索引上的数字，跟随机索引上的字母进行交换
            int index = r.nextInt(chars.length);
            char temp = chars[4];
            chars[4] = chars[index];
            chars[index] = temp;

        //7.将交换后的字符数组转回字符串
        //String code = chars.toString();//err  写错
        String code = new String(chars);//生成一个新的字符串，(new一个)
        //最后返回code
        return code;
    }
}
