package test;

import java.util.Random;

public class Test2 {
    public static void main(String[] args) {
        //需求：
        //把一个一维数组中的数据：0~15打乱
        //然后再按照4个一组的方式添加到二维数组中

        //1.定义一个一维数组
        int[] tempArr = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};

        //2.打乱数组中的数据顺序
        Random r = new Random();
        for (int i = 0; i < tempArr.length; i++) {
            int index = r.nextInt(tempArr.length);
            int temp = tempArr[i];
            tempArr[i] = tempArr[index];
            tempArr[index] = temp;
        }
        //遍历数组
        for (int i = 0; i < tempArr.length; i++) {
            System.out.print(tempArr[i] + " ");
        }
        System.out.println();

        //3.定义一个二维数组
        int[][] data = new int[4][4];
        //方法二：
        //4.遍历二维数组将数据添加到二维数组中
        int num = 0;
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {//data[i].length 一维数组的长度
                data[i][j] = tempArr[num];
                num++;
            }
        }
        //遍历二维数组
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print(data[i][j] + " ");
            }
            System.out.println();
        }
    }
}
