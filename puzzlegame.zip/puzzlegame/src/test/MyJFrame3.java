package test;

import javax.swing.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;


public class MyJFrame3 extends JFrame implements KeyListener {


    public MyJFrame3()  {
        JFrame jFrame = new JFrame();
        //设置界面的宽高
        jFrame.setSize(603, 680);
        //设置界面的标题
        jFrame.setTitle("拼图单机版 v1.0");
        //设置界面置顶
        jFrame.setAlwaysOnTop(true);
        //设置界面居中
        jFrame.setLocationRelativeTo(null);
        //取消内部默认居中方式
        jFrame.setLayout(null);
        //设置关闭模式
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        //创建一个按钮对象
        JButton jtb1 = new JButton("按钮");
        //设置位置和宽高
        jtb1.setBounds(0,0,100,50);

        //给按钮添加动作监听
        //jtb:组件对象，表示你要给哪个组件添加事件
        // addActionListener: 表示我要给组件添加哪个事件监听(动作监听包含鼠标左键点击，空格)
        // 参数:表示事件被触发之后要执行的代码
        jtb1.addKeyListener(this);


        //把按钮添加到界面当中
        jFrame.getContentPane().add(jtb1);


        //设置窗体显示
        jFrame.setVisible(true);
    }


    @Override
    public void keyTyped(KeyEvent e) {

    }

    //细节1：
    //如果我们按下一个按键没有松开，那么会重复的去调用KeyPressed方法
    //细节2：
    //键盘里面那么多按键，如何进行区分
    //每一个按键都有与之对应的编号
    @Override
    public void keyPressed(KeyEvent e) {
        System.out.println("输入了按键");
    }

    @Override
    public void keyReleased(KeyEvent e) {
        System.out.println("松开了按键");
        //获取键盘上每一个按键的编号
        int code = e.getKeyCode();
        //每一个按键都有与之对应的编号
        //这个编号与ASCII码没有什么关系
        if (code == 65){
            System.out.println("键盘键入的是A");
        }else if (code == 66){
            System.out.println("键盘键入的是B");
        }
    }
}
