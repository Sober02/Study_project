package test;

public class Test4 {
    public static void main(String[] args) {
        //new MyJFrame2();
        new MyJFrame3();
    }
}
